let hamburger = document.querySelector (".hamburger")
let mobileNav = document.querySelector ("mob-nav")








hamburger.addEventListener('click', function(){
	mobileNav.classList.add(".open");
})